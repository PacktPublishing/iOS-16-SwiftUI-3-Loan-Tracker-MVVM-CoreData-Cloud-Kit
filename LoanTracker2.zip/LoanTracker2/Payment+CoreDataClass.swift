//
//  Payment+CoreDataClass.swift
//  LoanTracker2
//
//  Created by David Kababyan on 12/02/2023.
//
//

import Foundation
import CoreData

@objc(Payment)
public class Payment: NSManagedObject {

}
