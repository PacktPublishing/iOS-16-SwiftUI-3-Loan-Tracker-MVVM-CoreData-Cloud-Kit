//
//  Date + Extension.swift
//  LoanTracker2
//
//  Created by David Kababyan on 12/02/2023.
//

import Foundation

extension Date {
    var intOfYear: Int? {
        Calendar.current.dateComponents([.year], from: self).year
    }
}
