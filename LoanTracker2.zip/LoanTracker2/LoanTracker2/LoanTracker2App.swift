//
//  LoanTracker2App.swift
//  LoanTracker2
//
//  Created by David Kababyan on 12/02/2023.
//

import SwiftUI

@main
struct LoanTracker2App: App {

    var body: some Scene {
        WindowGroup {
            AllLoansView()
                .environment(\.managedObjectContext, PersistenceController.shared.container.viewContext)
        }
    }
}
