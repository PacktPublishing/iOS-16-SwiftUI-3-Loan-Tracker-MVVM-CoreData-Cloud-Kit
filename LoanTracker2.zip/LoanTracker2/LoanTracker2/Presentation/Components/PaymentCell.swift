//
//  PaymentCell.swift
//  LoanTracker2
//
//  Created by David Kababyan on 12/02/2023.
//

import SwiftUI

struct PaymentCell: View {
    
    let amount: Double
    let date: Date
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(amount, format: .currency(code: "EUR"))
                .font(.headline)
                .fontWeight(.semibold)
            
            Text(date.formatted(date: .abbreviated, time: .omitted))
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }
}

struct PaymentCell_Previews: PreviewProvider {
    static var previews: some View {
        PaymentCell(amount: 400, date: Date())
    }
}
