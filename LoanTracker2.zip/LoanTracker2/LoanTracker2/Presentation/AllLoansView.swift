//
//  ContentView.swift
//  LoanTracker2
//
//  Created by David Kababyan on 12/02/2023.
//

import SwiftUI
import CoreData

struct AllLoansView: View {
    @Environment(\.managedObjectContext) var viewContext
    
    @State private var isAddLoanShowing = false
    
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Loan.startDate, ascending: true)],
                  animation: .default)
    private var loans: FetchedResults<Loan>
    
    @ViewBuilder
    private func addButton() -> some View {
        Button {
            isAddLoanShowing = true
        } label: {
            Image(systemName: "plus.circle")
                .font(.title3)
        }
        .padding([.vertical, .leading], 5)
    }
    
    var body: some View {

        NavigationStack {
            List {
                ForEach(loans) { loan in
                    NavigationLink(value: Destination.payment(loan)) {
                        LoanCell(name: loan.wrappedName, amount: loan.totalAmount, date: loan.wrappedDueDate)
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .navigationTitle("All loans")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    addButton()
                }
            }
            .sheet(isPresented: $isAddLoanShowing) {
                AddLoanView()
            }
            .navigationDestination(for: Destination.self) { destination in
                
                switch destination {
                case .payment(let loan):
                    PaymentsView(loan: loan)
                case .addPayment(let loan, let payment):
                    AddPaymentView(loan: loan, payment: payment)
                }
            }
        }
    }
    
    func deleteItems(offset: IndexSet) {
        withAnimation {
            offset.map { loans[$0] }.forEach(viewContext.delete)
            PersistenceController.shared.save()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        AllLoansView()
    }
}
